const express = require('express');
const app = express();
const router = express.Router();
var passport = require('passport');
const bodyParser = require('body-parser');
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Methods", "POST, PUT, OPTIONS, DELETE, GET");
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    res.header("Access-Control-Allow-Credentials", "true");
    next();
});
app.use('/', router);

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));
router.use(passport.initialize());
router.use(passport.session());

require('./configs/database');
const passportAuth = require('./configs/passport');
const properties = require('./configs/properties');
const logger = require('./configs/log');
const user = require('./routes/user');

router.use('/', (req, res, next) => {
    req.body = JSON.parse(JSON.stringify(req.body));
    req.sendRes = {
        status: properties.labels.failure,
        data: null,
        info: "",
        err: "",
        error: null
    }
    next();
});
var auth = "/auth"
router.use('/auth/', passportAuth.validateUser)

router.post("/login", user.login);
router.post(auth + "/createStudent", user.createStudent);
router.get(auth + "/getAvailableSubjectsForStudent", user.getAvailableSubjectsForStudent);
router.post(auth + "/saveStudentSubjects", user.saveStudentSubjects);
router.post(auth + "/getStudentSelectedSubjects", user.getStudentSelectedSubjects);

router.get('*', (req, res) => {
    req.sendRes.err = properties.labels.invalidGetReq;
    properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes);
});
router.post('*', (req, res) => {
    req.sendRes.err = properties.labels.invalidPostReq;
    properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes);
});
var server = app.listen(properties.port, () => {
    logger.info("Server started", "Running on http://localhost:" + server.address().port);
});
process.on('uncaughtException', (err, origin) => {
    logger.err("Process exception ", err)
    logger.err("Process exception origin ", origin)
});