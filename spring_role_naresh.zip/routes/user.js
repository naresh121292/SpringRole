const validation = require('../configs/validation');
const properties = require('../configs/properties');
const logger = require('../configs/log');
const userDAO = require('../dao/userDAO');
module.exports = {
    login: login,
    createStudent: createStudent,
    getAvailableSubjectsForStudent: getAvailableSubjectsForStudent,
    saveStudentSubjects: saveStudentSubjects,
    getStudentSelectedSubjects: getStudentSelectedSubjects
}
var userSubjects = {
    "5th" : ["Node.js", "Mongo", "React"],
    "6th": ["Redux", "Sequelize", "serverless", "React native"] 
}

function login(req, res) {
    logger.info("In login", req.body);
    if (validation.isValid(req.body)) {
        if (validation.isValid(req.body.email) && validation.isValid(req.body.password)) {
            req.body.email = req.body.email.toString().trim().toLowerCase();
            userDAO.login(req.body, (status, httpStatus, loginData) => {
                if (status) {
                    req.sendRes.status = properties.labels.success;
                    req.sendRes.data = {};
                    req.sendRes.data.token = loginData.token;
                }
                else {
                    req.sendRes.info = loginData;
                }
                properties.sendResponse(res, httpStatus, req.sendRes);
            });
        }
        else {
            req.sendRes.err = properties.labels.invalidData;
            properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes);
        }
    }
    else {
        req.sendRes.err = properties.labels.invalidData;
        properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes);
    }
}

function createStudent(req, res){
    logger.info("In createStudent", req.body);
    if(req.authUser.type == properties.userType.admin){
        if(validation.isValid(req.body.studentEmail) && validation.isValid(req.body.studentPassword) && validation.isValid(req.body.semester) && !isNaN(req.body.semester)){
            req.body.studentEmail = req.body.studentEmail.toString().trim().toLowerCase()
            req.body.semester = parseInt(req.body.semester)
            var student = {
                _id: req.body.studentEmail,
                created_timestamp : new Date(),
                email: req.body.studentEmail,
                password: req.body.studentPassword,
                semester: req.body.semester,
                subjects: [],
                type: "student"
            }
            userDAO.createStudent(student, (err, data)=>{
                if(err){
                    req.sendRes.error = {
                        errCode: properties.ERR_CODES.DATABASE_ERR,
                        errMsg: "Unable to add student",
                        err: err
                    }
                    properties.sendResponse(res, properties.httpStatus.unProcessable, req.sendRes);
                }
                else{
                    req.sendRes.status = properties.labels.success;
                    req.sendRes.info = "User created successfully"
                    properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
                }
            })
        }
        else{
            req.sendRes.error = {
                errCode: properties.ERR_CODES.INVALID_DATA,
                errMsg: properties.labels.invalidData,
                err: null
            }
            req.sendRes.err = properties.labels.invalidData
            properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes);
        }
    }
    else{
        req.sendRes.error = {
            errCode: properties.ERR_CODES.INVALID_USER,
            errMsg: properties.userLabels.notAuthorized,
            err: null
        } 
        properties.sendResponse(res, properties.httpStatus.unAuthorized, req.sendRes) 
    }
}

function getAvailableSubjectsForStudent(req, res){
    logger.info("In getAvailableSubjectsForUser");
    req.sendRes.status = properties.labels.success;
    if(req.authUser.type == "student"){
        (req.authUser.semester == 5) ? req.sendRes.data = { "subjects" : userSubjects["5th"]} : req.sendRes.data = { "subjects" : userSubjects["6th"]}
    }
    else{
        req.sendRes.info = "Not a student"
        req.sendRes.data = { "subjects" : []}
    }
    properties.sendResponse(res, properties.httpStatus.success, req.sendRes); 
}

function saveStudentSubjects(req, res){
    logger.info("In saveStudentSubjects", req.body);
    if(validation.isValid(req.body.subjects) && typeof(req.body.subjects) == 'object' && req.body.subjects.length > 0 ){
        if(req.authUser.type == "student"){
            var studentSubjects = []
            if(req.authUser.semester == 5 && userSubjects["5th"].indexOf(req.body.subjects[0]) > -1){
                studentSubjects = [req.body.subjects[0]]
            }
            else if(req.authUser.semester == 6 && req.body.subjects.length > 1){
                if(userSubjects["6th"].indexOf(req.body.subjects[0]) > -1 && userSubjects["6th"].indexOf(req.body.subjects[1]) > -1){
                    studentSubjects = [req.body.subjects[0], req.body.subjects[1]]
                }
            }
            if(studentSubjects.length > 0){
                var input = {
                    _id: req.authUser.email,
                    subjects: studentSubjects
                }
                userDAO.updateStudentSubjects(input, (err, data)=>{
                    if (err) {
                        req.sendRes.err = "Unable to update subjects"
                        properties.sendResponse(res, properties.httpStatus.unProcessable, req.sendRes); 
                    }
                    else{
                        req.sendRes.status = properties.labels.success;
                        req.sendRes.info = "Updated subjects"
                        properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
                    }
                })
            }
            else{
                req.sendRes.err = "Invalid subjects"
                properties.sendResponse(res, properties.httpStatus.unProcessable, req.sendRes);
            }
        }
        else{
            req.sendRes.err = "Not a student to select subjects"
            properties.sendResponse(res, properties.httpStatus.unAuthorized, req.sendRes);
        }
    }
    else{
        req.sendRes.err = properties.labels.invalidData;
        properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes); 
    }
}

function getStudentSelectedSubjects(req, res){
    if(req.authUser.type == "student"){
        req.sendRes.status = properties.labels.success;
        req.sendRes.data = {subjects : req.authUser.subjects}
        properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
    }
    else{
        if(validation.isValid(req.body.email)){
            req.body.email = req.body.email.toString().trim().toLowerCase()
            userDAO.getUserById(req.body.email, (student)=>{
                if(student != null){
                    req.sendRes.status = properties.labels.success;
                    req.sendRes.data = {subjects : student.subjects}
                }
                else{
                    req.sendRes.err = "Unable to get subjects/ No student found"
                }
                properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
            })
        }
        else{
            req.sendRes.err = properties.labels.invalidData;
            properties.sendResponse(res, properties.httpStatus.badReq, req.sendRes); 
        }
    }
}