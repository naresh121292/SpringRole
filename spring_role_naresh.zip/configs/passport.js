var passportJWT = require("passport-jwt");
var passport = require('passport');

var properties = require('./properties');
var logger = require('./log');
var userDAO = require('../dao/userDAO');

var JwtStrategy = passportJWT.Strategy;
var jwtOptions = {};
var sessionExtractor = function (request) {
    var token = null;
    if (request.headers.authorization) {
        token = request.headers.authorization;
    }
    return token;
};
jwtOptions.jwtFromRequest = sessionExtractor;
jwtOptions.secretOrKey = properties.keys.jwtSecretKey;
var strategy = new JwtStrategy(jwtOptions, function (jwt_payload, done) {
    logger.log('payload received', jwt_payload);
    done(jwt_payload);
});

passport.use(strategy);

module.exports = {
    validateUser: validateUser
}

function validateUser(req, res, next) {
    logger.info("In validateUser configs", req.headers.authorization);
    jwtOptions.secretOrKey = properties.keys.jwtSecretKey;
    passport.authenticate('jwt', (payload) => {
        if (payload != null) {
            userDAO.getUserById(payload.email, (user) => {
                //if (user != null && payload.key == user.password) {
                if (user != null && payload.key == user.password) {
                    logger.log("In getUserById User found ", user._id.toString());
                    req.authUser = user;
                    next();
                }
                else {
                    req.sendRes.error = {
                        errCode: properties.ERR_CODES.INVALID_USER,
                        errMsg: properties.labels.invalidAuthorization,
                        err: null
                    }
                    req.sendRes.err = properties.userLabels.invalidUser;
                    if (req.method == properties.httpMethods.options) {
                        properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
                    }
                    else {
                        properties.sendResponse(res, properties.httpStatus.unAuthorized, req.sendRes);
                    }
                }
            });
        }
        else {
            req.sendRes.error = {
                errCode: properties.ERR_CODES.INVALID_USER,
                errMsg: properties.labels.invalidAuthorization,
                err: null
            }
            req.sendRes.err = properties.userLabels.invalidUser;
            if (req.method == properties.httpMethods.options) {
                properties.sendResponse(res, properties.httpStatus.success, req.sendRes);
            }
            else {
                properties.sendResponse(res, properties.httpStatus.unAuthorized, req.sendRes);
            }
        }
    })(req, res);
}