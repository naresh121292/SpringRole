const MongoClient = require('mongodb').MongoClient;

const properties = require('./properties');
const logger = require('./log');
const userDAO = require('../dao/userDAO');

var database = null;

MongoClient.connect(properties.database.localHost, { useNewUrlParser: true, reconnectTries: Number.MAX_VALUE, reconnectInterval: 1000, useUnifiedTopology: true },
	function (err, client) {
		if (err) {
			logger.err("Unable to connect to database ", err);
		}
		else {
			var db = client.db(properties.database.dbName);
			logger.info("Database connected ", db.s.databaseName)
			database = db;
			userDAO.connectDb(database);
		}
	}
);


