module.exports = {
    log: log,
    info: info,
    err: err,
    warn: warn
}

function log(msg, input) {
    console.log((new Date()).toString(), msg, input);
}
function info(msg, input) {
    console.info((new Date()).toString(), msg, input);
}
function err(msg, input) {
    console.error((new Date()).toString(), msg, input);
}
function warn(msg, input) {
    console.warn((new Date()).toString(), msg, input);
}