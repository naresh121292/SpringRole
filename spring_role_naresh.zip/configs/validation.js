module.exports = {
    isValid: isValid,
    isValidEmail: isValidEmail
}

function isValid(data) {
    if (typeof (data) === 'object') {
        if (JSON.stringify(data) === '{}' || JSON.stringify(data) === '[]') {
            return false;
        } else if (!data) {
            return false;
        }
        return true;
    } else if (typeof (data) === 'string') {
        if (!data.trim()) {
            return false;
        }
        return true;
    } else if (typeof (data) === 'undefined') {
        return false;
    } else {
        return true;
    }
}

function isValidEmail(email) {
    email = email.toString().trim();
    if (typeof (email) === 'string') {
        if (!email.trim()) {
            return false;
        }
        else {
            var re = /^[a-zA-Z0-9_\-.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-.]+$/;
            return re.test(email);
        }
    } else {
        return false;
    }
}