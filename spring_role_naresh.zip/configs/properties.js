module.exports = {
	port: '8123',
	database: {
		localHost: "mongodb://naresh:naresh@localhost:27017/",
		dbName: "SpringRole",
		collection: {
			users: "users"
		}
	},
	
	httpStatus: {
		success: 200,
		badReq: 400,
		unAuthorized: 401,
		unProcessable: 422,
		internalError: 500
	},
	httpMethods: {
		post: "POST",
		options: "OPTIONS",
		get: "GET",
		put: "PUT"
	},
	userType: {
		admin: "admin",
		student: "student"
	},
	labels: {
		success: "success",
		failure: "failure",
		dbErr: "Database error",
		invalidData: "Invalid input data",
		unknownErr: "Unknown error",
		invalidGetReq: "Invalid GET request",
		invalidPostReq: "Invalid POST request",
		invalidAuthorization: "Invalid Authorization key"
	},
	userLabels: {
		noUser: "User not found",
		invalidUser: "Invalid user",
		notAuthorized: "Not authorized user",
		noUsers: "No users found"
	},
	keys: {
		jwtSecretKey: "spring"
	},
	ERR_CODES: {
		DATABASE_ERR: 1001,
		INVALID_DATA: 1002,
		INVALID_USER: 1003
	}
}

module.exports.sendResponse = function (res, httpStatus, result) {
	if (res.headersSent == false) {
		res.status(httpStatus);
		res.json(result);
		res.end();
	}
}