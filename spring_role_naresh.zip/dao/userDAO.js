const properties = require('../configs/properties');
const logger = require('../configs/log');
var jwt = require('jsonwebtoken');
module.exports = {
	connectDb: connectDb,
	getUserById: getUserById,
	login: login,
	createStudent: createStudent,
	updateStudentSubjects: updateStudentSubjects
}
var db;

function connectDb(database) {
	logger.info("Db set to user dao", database.s.databaseName);
	db = database;
}

function getUserById(email, cb) {
	logger.info("In getUserById dao", email);
	db.collection(properties.database.collection.users).findOne({
		'email': email
	}, function (err, user) {
		if (err) {
			cb(null);
		}
		else if (user) {
			cb(user);
		}
		else {
			cb(null);
		}
	}
	);
}

function login(input, cb) {
	logger.info("In login dao", input);
	var query = { "email": input.email };
	db.collection(properties.database.collection.users).findOne(query, function (err, user) {
		if (err)
			cb(false, properties.httpStatus.internalError, properties.labels.dbErr);

		else if (user) {
			if (user.password == input.password) {
				var payload = { 'email': user.email, 'key': user.password };
				var result = {};
				result.token = jwt.sign(payload, properties.keys.jwtSecretKey);
				cb(true, properties.httpStatus.success, result);
			}
			else {
				cb(false, properties.httpStatus.unProcessable, properties.userLabels.wrongPassword);
			}
		}
		else {
			cb(false, properties.httpStatus.unProcessable, properties.userLabels.noUser);
		}

	});
}

function createStudent(input, cb) {
	logger.info("In createStudent dao", input);
	db.collection(properties.database.collection.users).insertOne(input, (err, data) => {
		cb(err, data)
	});
}

function updateStudentSubjects(input, cb) {
	logger.info("In updateStudentSubjects dao", input);
	var update = {
		$set: { "subjects": input.subjects }
	}
	db.collection(properties.database.collection.users).updateOne({_id: input._id}, update, { upsert: false },
		function (err, res) {
			if (err) {
				logger.err(err)
				cb(err, null)
			}
			else {
				logger.log("Successfully updated subjects")
				cb(null, res)
			}
		})
}